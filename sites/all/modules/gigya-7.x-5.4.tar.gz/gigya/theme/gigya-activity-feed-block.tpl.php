<?php

/**
 * @file gigya-activity-feed-block.tpl.php
 * Default theme implementation for displaying a gigya activity feed.
 *
 */
?>

<div id="<?php print $continer_id ?>"></div>
